package ma.finexa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ma.finexa.dao.ProductRepository;
import ma.finexa.entities.Product;

@SpringBootApplication
public class MsProductApplication implements CommandLineRunner {
	
	@Autowired
	ProductRepository pr;

	public static void main(String[] args) {
		SpringApplication.run(MsProductApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		pr.save(new Product(null, "asus", 5900.23, "InformatIque"));
		pr.save(new Product(null, "TV", 4000.23, "Electromenager"));
		pr.save(new Product(null, "asus", 5900.23, "informatique"));
		
		System.out.println("=========== all products ===============");
		for (Product prd:pr.findAll()) {
			System.out.println(prd.toString());
		}
		
		System.out.println("=========== one product : 2 ===============");
		System.out.println(pr.findById(2L).get().toString());
		
		
		System.out.println("=========== all products : informatique ===============");
		for (Product prd:pr.findByCategory("informatique")) {
			System.out.println(prd.toString());
		}
		
		System.out.println(pr);
		
	}

}
